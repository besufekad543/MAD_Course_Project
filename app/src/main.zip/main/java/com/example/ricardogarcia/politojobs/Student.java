package com.example.ricardogarcia.politojobs;

/**
 * Created by ricardogarcia on 30/04/15.
 */
public class Student {
}
